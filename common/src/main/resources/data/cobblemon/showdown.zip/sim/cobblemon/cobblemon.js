"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var cobblemon_exports = {};
__export(cobblemon_exports, {
  Cobblemon: () => Cobblemon
});
module.exports = __toCommonJS(cobblemon_exports);
var import_registries = require("./registries");
const Cobblemon = {
  modId: "cobblemon",
  abilityRegistry: new import_registries.AbilityRegistry(),
  bagItemRegistry: new import_registries.BagItemRegistry(),
  heldItemRegistry: new import_registries.HeldItemRegistry(),
  moveRegistry: new import_registries.MoveRegistry(),
  speciesRegistry: new import_registries.SpeciesRegistry()
};
//# sourceMappingURL=cobblemon.js.map
