"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var cobbled_debug_server_exports = {};
__export(cobbled_debug_server_exports, {
  startServer: () => startServer
});
module.exports = __toCommonJS(cobbled_debug_server_exports);
var import_battle_stream = require("../battle-stream");
var import_dex = require("../dex");
var Net = __toESM(require("net"));
var import_cobblemon = require("./cobblemon");
const toID = import_dex.Dex.toID;
function startServer(port) {
  const server = Net.createServer();
  const battleMap = /* @__PURE__ */ new Map();
  server.listen(port, () => {
    console.log("Server listening for connection requests on socket localhost: " + port);
  });
  server.on("connection", (socket) => onConnection(socket, battleMap));
}
function onData(socket, chunk, battleMap) {
  const data = chunk.toString();
  const lines = data.split("\n");
  lines.forEach((line) => {
    console.log("Data received from client: " + line.toString());
    if (line.startsWith(">startbattle")) {
      const battleId = line.split(" ")[1];
      battleMap.set(battleId, new import_battle_stream.BattleStream());
      socket.write("ACK");
    } else if (line.startsWith(">receiveAbilityData")) {
      const abilityId = line.split(" ")[1];
      try {
        var content = line.slice(line.indexOf(abilityId) + abilityId.length + 1);
        import_cobblemon.Cobblemon.abilityRegistry.register(content, toID(abilityId));
        socket.write("ACK");
      } catch (e) {
        console.error(e);
        socket.write("ERR");
      }
    } else if (line.startsWith(">receiveBagItemData")) {
      const itemId = line.split(" ")[1];
      try {
        var content = line.slice(line.indexOf(itemId) + itemId.length + 1);
        import_cobblemon.Cobblemon.bagItemRegistry.register(content, toID(itemId));
        socket.write("ACK");
      } catch (e) {
        console.error(e);
        socket.write("ERR");
      }
    } else if (line.startsWith(">receiveHeldItemData")) {
      const itemId = line.split(" ")[1];
      try {
        var content = line.slice(line.indexOf(itemId) + itemId.length + 1);
        import_cobblemon.Cobblemon.heldItemRegistry.register(content, toID(itemId));
        socket.write("ACK");
      } catch (e) {
        console.error(e);
        socket.write("ERR");
      }
    } else if (line.startsWith(">receiveMoveData")) {
      const moveId = line.split(" ")[1];
      try {
        var content = line.slice(line.indexOf(moveId) + moveId.length + 1);
        import_cobblemon.Cobblemon.moveRegistry.register(content, toID(moveId));
        socket.write("ACK");
      } catch (e) {
        console.error(e);
        socket.write("ERR");
      }
    } else if (line === ">getMoves") {
      getMoves(socket);
    } else if (line === ">getAbilityIds") {
      getAbilityIds(socket);
    } else if (line === ">getHeldItemIds") {
      getHeldItemIds(socket);
    } else if (line === ">getTypeChart") {
      getTypeChart(socket);
    } else if (line === ">resetSpeciesData") {
      import_cobblemon.Cobblemon.speciesRegistry.reset();
      socket.write("ACK");
    } else if (line.startsWith(">receiveSpeciesData")) {
      const speciesJson = line.replace(`>receiveSpeciesData `, "");
      const species = JSON.parse(speciesJson);
      import_cobblemon.Cobblemon.speciesRegistry.register(species);
      socket.write("ACK");
    } else if (line === ">afterSpeciesInit") {
      afterSpeciesInit();
      socket.write("ACK");
    } else {
      const [battleId, showdownMsg] = line.split("~");
      const battleStream = battleMap.get(battleId);
      if (battleStream) {
        try {
          void battleStream.write(showdownMsg);
        } catch (err) {
          console.error(err.stack);
        }
        writeBattleOutput(socket, battleStream);
      }
    }
  });
}
function writeBattleOutput(socket, battleStream) {
  const messages = battleStream.buf;
  if (messages.length !== 0) {
    socket.write(padNumber(messages.length, 8));
    for (const message of messages) {
      socket.write(padNumber(message.length, 8) + message);
    }
  } else {
    writeVoid(socket);
  }
  battleStream.buf = [];
}
function writeVoid(socket) {
  socket.write("00000000");
}
function onConnection(socket, battleMap) {
  socket.on("data", (chunk) => {
    try {
      onData(socket, chunk, battleMap);
    } catch (error) {
      console.error(error);
    }
  });
  socket.on("end", () => console.log("Closing connection with the client"));
  socket.on("error", (err) => console.error(err.stack));
}
function getMoves(socket) {
  let combined = Array.from(import_dex.Dex.mod(import_cobblemon.Cobblemon.modId).moves.all());
  import_cobblemon.Cobblemon.moveRegistry.contents.forEach((move, id) => {
    let existing = combined.find((_move) => _move.id == id);
    if (existing) {
      combined[combined.indexOf(existing)] = move;
    } else {
      combined.push(move);
    }
  });
  const payload = JSON.stringify(combined);
  socket.write(padNumber(payload.length, 8) + payload);
}
function getAbilityIds(socket) {
  let combined = Array.from(import_dex.Dex.mod(import_cobblemon.Cobblemon.modId).abilities.all());
  import_cobblemon.Cobblemon.abilityRegistry.contents.forEach((ability, id) => {
    let existing = combined.find((_ability) => _ability.id == id);
    if (existing) {
      combined[combined.indexOf(existing)] = ability;
    } else {
      combined.push(ability);
    }
  });
  const payload = JSON.stringify(combined.map((ability) => ability.id));
  socket.write(padNumber(payload.length, 8) + payload);
}
function getHeldItemIds(socket) {
  const payload = JSON.stringify(import_dex.Dex.mod(import_cobblemon.Cobblemon.modId).items.all().map((item) => item.id));
  socket.write(padNumber(payload.length, 8) + payload);
}
function getTypeChart(socket) {
  const payload = JSON.stringify(import_dex.Dex.data.TypeChart);
  socket.write(padNumber(payload.length, 8) + payload);
}
function afterSpeciesInit() {
  import_dex.Dex.modsLoaded = false;
  import_dex.Dex.includeMods();
}
function padNumber(num, size) {
  let numStr = num.toString();
  while (numStr.length < size)
    numStr = "0" + numStr;
  return numStr;
}
//# sourceMappingURL=cobbled-debug-server.js.map
